# CS205B Shift 1 — Solutions Guide

This ZIP contains the **50 original problem notebooks** plus this implementation guide. Keep each notebook's locked cells unchanged. Paste the corresponding code into the student implementation cells (usually Cell 4 and Cell 5), then run the notebook from top to bottom.

## Categories 01, 02, 04, 08, 11 and 12 — Tabular Q-learning

### Cell 4: epsilon-greedy action selection
```python
def choose_action(self, state):
    if random.random() < self.epsilon:
        return random.randrange(self.num_actions)
    best_actions = np.flatnonzero(
        self.q_table[state] == np.max(self.q_table[state])
    )
    return int(random.choice(best_actions.tolist()))
```

### Cell 5: Bellman Q-learning update
```python
def update_agent(self, state, action, reward, next_state, done):
    if done:
        target = reward
    else:
        target = reward + self.gamma * np.max(self.q_table[next_state])
    self.q_table[state, action] += self.alpha * (
        target - self.q_table[state, action]
    )

QLearningAgent.update_agent = update_agent
```
For Category 08, use `PursuitEvasionAgent.update_agent = update_agent`; for Category 11/12 use the class name shown in that notebook. The formula is identical.

## Category 03 — Smart cleaning robot

### Problem 03: remember dirt and recently cleaned cells
```python
def choose_action(self, percept):
    pos = tuple(percept["position"])
    self.visited.add(pos)
    if percept.get("dirt", False) or percept.get("is_dirty", False):
        return "CLEAN"
    if percept.get("battery", 100) <= 15:
        return self._move_to_dock(percept)
    valid = percept.get("valid_moves", [])
    fresh = []
    delta = {"UP":(-1,0), "DOWN":(1,0), "LEFT":(0,-1), "RIGHT":(0,1)}
    for action in valid:
        dr, dc = delta[action]
        if (pos[0]+dr, pos[1]+dc) not in self.cleaned_recently:
            fresh.append(action)
    return random.choice(fresh or valid) if valid else "RECHARGE"

def update_agent(self, percept, action, reward, next_percept, done):
    pos = tuple(percept["position"])
    if percept.get("dirt", False) or percept.get("is_dirty", False):
        self.dirty_memory.add(pos)
    if action == "CLEAN" and reward > 0:
        self.cleaned_recently.add(pos)
        self.dirty_memory.discard(pos)
SmartCleaningAgent.update_agent = update_agent
```

### Problem 04: obstacle-aware cleaning
```python
def choose_action(self, percept):
    if percept.get("dirt", False) or percept.get("is_dirty", False):
        return "CLEAN"
    self.blocked_memory.update(percept.get("blocked", []))
    valid = [a for a in percept.get("valid_moves", [])
             if a not in self.blocked_memory]
    return random.choice(valid) if valid else "RECHARGE"

def update_agent(self, percept, action, reward, next_percept, done):
    self.blocked_memory.update(percept.get("blocked", []))
    old = self.action_value.get(action, 0.0)
    self.action_value[action] = old + self.alpha * (reward - old)
SmartCleaningAgent.update_agent = update_agent
```

### Problem 05: priority-based cleaning
```python
def choose_action(self, percept):
    level = percept.get("dirt_level", 0)
    self.priority_score += float(level)
    if level >= 2:
        return "CLEAN"
    valid = percept.get("valid_moves", [])
    return random.choice(valid) if valid else "RECHARGE"

def update_agent(self, percept, action, reward, next_percept, done):
    if action == "CLEAN" and reward > 0:
        self.priority_score += float(reward)
    else:
        self.priority_score *= 0.95
    self.priority_score = max(0.0, self.priority_score)
SmartCleaningAgent.update_agent = update_agent
```

### Problem 06: battery-aware return to dock
```python
def choose_action(self, percept):
    pos = tuple(percept["position"])
    battery = float(percept.get("battery", 100))
    distance_to_dock = abs(pos[0]) + abs(pos[1])
    if pos == (0, 0) and battery < 80:
        return "RECHARGE"
    if battery < 2 * distance_to_dock + 10:
        return self._move_to_dock(percept)
    if percept.get("dirt", False) or percept.get("is_dirty", False):
        return "CLEAN"
    valid = percept.get("valid_moves", [])
    return random.choice(valid) if valid else "RECHARGE"

def update_agent(self, percept, action, reward, next_percept, done):
    battery = float(percept.get("battery", 100))
    self.battery_history.append(battery)
    self.min_battery = min(self.min_battery, battery)
SmartCleaningAgent.update_agent = update_agent
```
If a notebook uses slightly different percept-key names, follow the exact keys in its locked environment's `step()`/percept construction.

## Category 05 — Grid-game Q-learning

All these agents use a multidimensional Q-table. Use the state tuple directly as the NumPy index.

### Snake / Breakout / Pac-Man / Space Invaders: Cell 4
```python
def choose_action(self, state):
    if random.random() < self.epsilon:
        return random.randrange(self.q_table.shape[-1])
    values = self.q_table[state]
    best = np.flatnonzero(values == np.max(values))
    return int(random.choice(best.tolist()))
```

### Snake / Breakout / Pac-Man / Space Invaders: Cell 5
For a method inside the class:
```python
def update_agent(self, state, action, reward, next_state, done):
    current = self.q_table[state][action]
    target = reward if done else reward + self.gamma * np.max(self.q_table[next_state])
    self.q_table[state][action] = current + self.alpha * (target - current)
```
For the free-standing function in Space Invaders, use `agent_obj` in place of `self` and assign with `SpaceInvadersAgent.update_agent = update_agent`.

### Frog-crossing Problem 06
```python
def get_state(frog_x, frog_y, obstacles):
    return tuple(int(obstacles.get(lane, frog_x) - frog_x)
                 for lane in (1, 2, 3)) + (int(frog_y),)

def choose_action(state, epsilon):
    initialize_state_if_needed(state)
    if random.random() < epsilon:
        return random.randrange(len(q_table[state]))
    return int(np.argmax(q_table[state]))

def update_q_table(state, action, reward, next_state, alpha, gamma):
    initialize_state_if_needed(state)
    initialize_state_if_needed(next_state)
    target = reward + gamma * np.max(q_table[next_state])
    q_table[state][action] += alpha * (target - q_table[state][action])
```

## Category 06 — Game theory and strategic decisions

### Problem 02: 2×2 zero-sum game
```python
def solve_2x2_zero_sum(M):
    M = np.asarray(M, dtype=float)
    row_min = M.min(axis=1)
    col_max = M.max(axis=0)
    maximin, minimax = np.max(row_min), np.min(col_max)
    if np.isclose(maximin, minimax):
        return float(np.argmax(row_min) == 0), float(np.argmin(col_max) == 0), float(maximin)
    a, b, c, d = M[0,0], M[0,1], M[1,0], M[1,1]
    den = a - b - c + d
    p, q = (d-c)/den, (d-b)/den
    v = (a*d-b*c)/den
    return float(p), float(q), float(v)

def effect_of_training(M, new_a):
    old = np.asarray(M, dtype=float).copy()
    new = old.copy()
    new[0,0] = new_a
    p0,q0,v0 = solve_2x2_zero_sum(old)
    p1,q1,v1 = solve_2x2_zero_sum(new)
    return dict(p_old=p0, p_new=p1, q_old=q0, q_new=q1, v_old=v0, v_new=v1)

def constrained_keeper(M, q_min, grid=3001):
    M = np.asarray(M, dtype=float)
    best = None
    for q in np.linspace(q_min, 1, grid):
        payoffs = M[:,0]*q + M[:,1]*(1-q)
        row = int(np.argmax(payoffs))
        candidate = (float(q), row, float(payoffs[row]))
        if best is None or candidate[2] < best[2]:
            best = candidate
    return best
```

### Problem 03: 2×2 Nash equilibrium and bargaining
```python
def nash_2x2(A, B):
    A, B = np.asarray(A, float), np.asarray(B, float)
    pure = [(i,j) for i in range(2) for j in range(2)
            if A[i,j] >= np.max(A[:,j])-1e-9
            and B[i,j] >= np.max(B[i,:])-1e-9]
    da = A[0,0]-A[0,1]-A[1,0]+A[1,1]
    db = B[0,0]-B[0,1]-B[1,0]+B[1,1]
    mixed = None
    if abs(da)>1e-12 and abs(db)>1e-12:
        q = (A[1,1]-A[0,1])/da
        p = (B[1,1]-B[1,0])/db
        if 0<p<1 and 0<q<1:
            uA = p*q*A[0,0]+p*(1-q)*A[0,1]+(1-p)*q*A[1,0]+(1-p)*(1-q)*A[1,1]
            uB = p*q*B[0,0]+p*(1-q)*B[0,1]+(1-p)*q*B[1,0]+(1-p)*(1-q)*B[1,1]
            mixed = dict(p=float(p), q=float(q), uA=float(uA), uB=float(uB))
    return pure, mixed

def pareto_dominates(u, v):
    return all(a >= b for a,b in zip(u,v)) and any(a > b for a,b in zip(u,v))

def stackelberg(A, B):
    A, B = np.asarray(A), np.asarray(B)
    candidates = []
    for i in range(A.shape[0]):
        j = int(np.argmax(B[i]))
        candidates.append((A[i,j], i, j))
    _, i, j = max(candidates, key=lambda x: (x[0], -x[1]))
    return i, j, float(A[i,j]), float(B[i,j])

def min_subsidy(A, B, step=0.01, s_max=10):
    for s in np.arange(0, s_max + step/2, step):
        Bs = np.asarray(B, float).copy()
        Bs[:,1] += s
        if pure_nash(A, Bs) == [(1,1)]:
            return round(float(s), 10)
    return None
```

### Problem 04: Cournot duopoly
```python
def payoff_matrices(qs, a=12):
    qs = np.asarray(qs, dtype=float)
    A = np.zeros((len(qs), len(qs)))
    B = np.zeros_like(A)
    for i, q1 in enumerate(qs):
        for j, q2 in enumerate(qs):
            A[i,j] = q1 * (a-q1-q2)
            B[i,j] = q2 * (a-q1-q2)
    return A, B

def joint_profit_max(A, B, qs):
    total = np.asarray(A) + np.asarray(B)
    mx = np.max(total)
    return [(qs[i], qs[j], float(total[i,j]))
            for i in range(total.shape[0]) for j in range(total.shape[1])
            if np.isclose(total[i,j], mx)]

def best_deviation_gain(A, B, i, j):
    return float(np.max(A[:,j])-A[i,j]), float(np.max(B[i,:])-B[i,j])

def equilibrium_cs(qs, a=12):
    A, B = payoff_matrices(qs, a)
    out = []
    for i,j in pure_nash(A,B):
        Q = qs[i] + qs[j]
        out.append((qs[i], qs[j], Q, float(Q**2/2)))
    return out
```

### Problem 05: repeated Prisoner's Dilemma
```python
def pd_parameters(A):
    R, S, T, P = float(A[0,0]), float(A[0,1]), float(A[1,0]), float(A[1,1])
    return T, R, P, S, bool(T>R>P>S and 2*R>T+S)

def grim_threshold(T, R, P):
    return float((T-R)/(T-P)) if T != P else 1.0

def tft_thresholds(T, R, P, S):
    one_shot = (T-R)/(R-S) if R != S else float("inf")
    forever = (T-R)/(T-P) if T != P else float("inf")
    return {"one_shot_then_cooperate": one_shot,
            "defect_forever": forever,
            "alternate_D_C": one_shot,
            "required": max(one_shot, forever)}

def classify_game(x, base=((12,4),(16,8))):
    A = np.array(base, dtype=float)
    A[1,:] -= x
    T,R,P,S = A[1,0], A[0,0], A[1,1], A[0,1]
    if T>R>P>S and 2*R>T+S: return "Prisoner's Dilemma"
    if np.isclose(T,R) and np.isclose(P,S): return "Degenerate (indifferent)"
    if R>T and S>P: return "Harmony (cooperation dominant)"
    return "Other"
```

## Category 07 — Cooperative task allocation

The state is the remaining-task vector and each agent has its own action-value vector.
```python
def choose_action(state, q_table, epsilon=EPSILON):
    available = [i for i, remaining in enumerate(state) if remaining]
    if not available:
        return 0
    if random.random() < epsilon:
        return random.choice(available)
    best_value = max(q_table[i] for i in available)
    return random.choice([i for i in available if q_table[i] == best_value])

def update_q_value(q_table, action, reward, next_state,
                   alpha=ALPHA, gamma=GAMMA):
    next_available = [i for i, remaining in enumerate(next_state) if remaining]
    future = max((q_table[i] for i in next_available), default=0.0)
    target = reward + gamma * future
    q_table[action] += alpha * (target - q_table[action])
```
This version avoids selecting tasks already completed in the environment.

## Category 09 — Rule-based traffic signal agent

### Problem 03: queue plus waiting time
```python
def choose_action(self, state):
    nsq, ewq, nsw, eww = state
    ns_score, ew_score = nsq+nsw, ewq+eww
    action = 0 if ns_score > ew_score else 1 if ew_score > ns_score else self.current_phase
    self.current_phase = action
    return action

def update_agent(self, state, action, reward, next_state, done):
    before, after = sum(state), sum(next_state)
    reduction = max(0, before-after)
    self.congestion_estimate[action] += self.alpha * (
        reduction-self.congestion_estimate[action])
TrafficLightAgent.update_agent = update_agent
```

### Problem 04: threshold-based priority
```python
def choose_action(self, state):
    nsq, ewq, phase = state
    if nsq >= 7 and ewq >= 7:
        action = 0 if nsq >= ewq else 1
    elif nsq >= 7: action = 0
    elif ewq >= 7: action = 1
    else: action = phase
    self.current_phase = action
    return action
```

### Problem 05: emergency vehicle priority
```python
def choose_action(self, state):
    nsq, ewq, emergency_ns, emergency_ew = state
    if emergency_ns and emergency_ew:
        action = 0 if nsq >= ewq else 1
    elif emergency_ns: action = 0
    elif emergency_ew: action = 1
    else: action = 0 if nsq >= ewq else 1
    self.current_phase = action
    return action
```

### Problem 06: rush-hour priority
```python
def choose_action(self, state):
    nsq, ewq, hour = state
    rush = 8 <= hour <= 10 or 17 <= hour <= 19
    ns_score = nsq + (2 if rush else 0)
    action = 0 if ns_score > ewq else 1 if ewq > ns_score else self.current_phase
    self.current_phase = action
    return action
```
For Problems 04–06, implement Cell 5 using the exact running-estimate/success-estimate variable described in that notebook's task comments.

## Category 10 — Multi-agent Contract Net Protocol (CNP)

These four problems share eligibility checks but use **different utility formulas and feedback signals**. Do not copy one problem's weights into another. Apply the exact formula in each notebook's problem statement.

### Shared eligibility logic (individual contractor)
```python
req = state["request"]
feasible = []
for bid in state["bids"]:
    if bid["capacity"] < req["qty"]:
        continue
    if req.get("need_flag", 0) and not bid.get("capability", 0):
        continue
    if METRIC_DIRECTION == "min" and bid["metric"] < req["min_metric"]:
        continue
    if METRIC_DIRECTION == "max" and bid["metric"] > req["min_metric"]:
        continue
    if bid["price"] > req["budget"] or bid["eta"] > req["deadline"]:
        continue
    feasible.append(bid)
```

For Category10 Problem 03, score each feasible bid as:
```python
utility = (req["priority"] * (7*bid["quality"] + 4*bid["metric"])
           + 11*self.gamma*self.trust[bid["id"]]
           - 0.28*bid["price"] - 1.90*bid["eta"]
           - 1.70*self.workload[bid["id"]])
```
Choose the maximum utility (lowest ID breaks ties); with probability `EPSILON`, choose a random feasible bidder.

Trust update for Problem 03:
```python
if feedback["awarded"]:
    for i in feedback["selected"]:
        y = 0.5*float(feedback["individual_outcomes"].get(i, feedback["success"])) \
            + 0.5*float(feedback["on_time"])
        manager.trust[i] = np.clip((1-manager.alpha)*manager.trust[i]
                                   + manager.alpha*y, 0, 1)
        manager.workload[i] += 1
```

For Problems 04–06, use their own utility and feedback definitions from the source:
- **P04:** quality and trust are positive; price, ETA, emissions and workload are costs. Feedback signal = 0.50 success + 0.25 punctuality + 0.25 observed sorting quality.
- **P05:** voltage quality and learned trust are positive; price, carbon intensity and response time are costs. Feedback signal = 0.65 correct energy delivery + 0.35 response within SLA.
- **P06:** precision, shielding and trust are positive; price, ETA and workload are costs. Feedback signal = 0.70 task success + 0.30 observed manipulation quality.

Generic trust update:
```python
manager.trust[i] = np.clip(
    (1-manager.alpha)*manager.trust[i] + manager.alpha*observed_signal,
    0.0, 1.0
)
manager.workload[i] += 1
```
If the problem uses `TEAM_MODE`, the action must be a valid `(picker_id, packer_id)` pair satisfying both roles and all budget/deadline/eligibility checks.

## Important run instructions
1. Open the notebook matching your category and problem number.
2. Keep all cells marked **LOCKED** unchanged.
3. Paste the matching implementation into the student cells.
4. Run **Kernel → Restart & Run All** (or Runtime → Run all in Colab).
5. If a notebook's percept/state keys differ, use the exact field names from that notebook's environment code rather than guessing.
